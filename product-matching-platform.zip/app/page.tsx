'use client'

import { useMemo, useState } from 'react'
import {
  ArrowDownAZ,
  ArrowUpDown,
  BarChart3,
  Bell,
  Bookmark,
  BookOpen,
  Check,
  ChevronDown,
  Database,
  ExternalLink,
  Filter,
  Hash,
  LayoutDashboard,
  ListFilter,
  Menu,
  Network,
  Search,
  Settings2,
  ShoppingBag,
  MessageCircle,
  Send,
  SlidersHorizontal,
  Sparkles,
  Tag,
  TrendingDown,
  X,
} from 'lucide-react'

type Listing = {
  id: string
  title: string
  seller: string
  price: number
  condition: string
  match: number
  image: string
  isCanonical?: boolean
}

const listings: Listing[] = [
  { id: 'p1', title: 'Sony WH-1000XM5 Wireless Noise Canceling Headphones', seller: 'Amazon', price: 348, condition: 'New', match: 98, image: '/images/product-catalog.png', isCanonical: true },
  { id: 'p2', title: 'Sony WH1000XM5/B Wireless Headphones Black', seller: 'Best Buy', price: 329.99, condition: 'New', match: 96, image: '/images/product-catalog.png' },
  { id: 'p3', title: 'Sony WH-1000XM5 Noise Cancelling Headphones', seller: 'Walmart', price: 299, condition: 'New', match: 94, image: '/images/product-catalog.png' },
  { id: 'p4', title: 'Sony WH1000XM5 Wireless Headphones (Black)', seller: 'eBay', price: 279.95, condition: 'Open box', match: 91, image: '/images/product-catalog.png' },
  { id: 'p5', title: 'Sony WH-1000XM5 Wireless Noise Cancelling', seller: 'Target', price: 349.99, condition: 'New', match: 89, image: '/images/product-catalog.png' },
  { id: 'p6', title: 'Sony XM5 Wireless Headphones with Mic', seller: 'Newegg', price: 315, condition: 'New', match: 84, image: '/images/product-catalog.png' },
  { id: 'p7', title: 'Sony WH-1000XM5 Bluetooth Headphones Silver', seller: 'Croma', price: 339.5, condition: 'New', match: 88, image: '/images/product-catalog.png' },
  { id: 'p8', title: 'Sony WH1000XM5 Premium Wireless Headset', seller: 'Reliance Digital', price: 307.25, condition: 'New', match: 86, image: '/images/product-catalog.png' },
  { id: 'p9', title: 'Sony WH-1000XM5 Wireless Headphones Refurbished', seller: 'Cashify', price: 249.99, condition: 'Refurbished', match: 82, image: '/images/product-catalog.png' },
  { id: 'p10', title: 'Sony WH-1000XM5 Noise Cancelling Over-Ear', seller: 'Flipkart', price: 319.99, condition: 'New', match: 90, image: '/images/product-catalog.png' },
  { id: 'p11', title: 'Sony WH-1000XM5 Headphones Midnight Blue', seller: 'Vijay Sales', price: 344.95, condition: 'New', match: 87, image: '/images/product-catalog.png' },
  { id: 'p12', title: 'Sony WH-1000XM5 Wireless Headphones Used', seller: 'OLX', price: 218.5, condition: 'Used', match: 78, image: '/images/product-catalog.png' },
  { id: 'p13', title: 'Apple MacBook Air M3 13-inch 8GB 256GB', seller: 'Amazon India', price: 999, condition: 'New', match: 97, image: '/images/product-catalog.png' },
  { id: 'p14', title: 'Apple MacBook Air M3 Midnight Laptop', seller: 'Croma', price: 949, condition: 'New', match: 93, image: '/images/product-catalog.png' },
  { id: 'p15', title: 'Samsung Galaxy S24 Ultra 5G 256GB', seller: 'Flipkart', price: 1099, condition: 'New', match: 96, image: '/images/product-catalog.png' },
  { id: 'p16', title: 'Samsung Galaxy S24 Ultra Titanium Gray', seller: 'Reliance Digital', price: 1049, condition: 'New', match: 91, image: '/images/product-catalog.png' },
  { id: 'p17', title: 'Sony PlayStation 5 Slim Disc Edition', seller: 'Vijay Sales', price: 599, condition: 'New', match: 98, image: '/images/product-catalog.png' },
  { id: 'p18', title: 'Apple iPad 10th Generation Wi-Fi 64GB', seller: 'Cashify', price: 429, condition: 'Refurbished', match: 89, image: '/images/product-catalog.png' },
  { id: 'p19', title: 'Dyson V12 Detect Slim Cordless Vacuum', seller: 'Tata Cliq', price: 649, condition: 'New', match: 95, image: '/images/product-catalog.png' },
  { id: 'p20', title: 'Nike Air Max 270 React Running Shoes', seller: 'Myntra', price: 149, condition: 'New', match: 88, image: '/images/product-catalog.png' },
  { id: 'p21', title: 'Atomberg Efficio Plus Smart Ceiling Fan 1200mm', seller: 'Amazon India', price: 89, condition: 'New', match: 96, image: '/images/product-catalog.png' },
  { id: 'p22', title: 'Crompton Energion Hyperjet Ceiling Fan', seller: 'Flipkart', price: 54, condition: 'New', match: 91, image: '/images/product-catalog.png' },
  { id: 'p23', title: 'LG 1.5 Ton 5 Star AI Dual Inverter Split AC', seller: 'Croma', price: 599, condition: 'New', match: 97, image: '/images/product-catalog.png' },
  { id: 'p24', title: 'Voltas 1.5 Ton Adjustable Inverter AC', seller: 'Reliance Digital', price: 479, condition: 'New', match: 93, image: '/images/product-catalog.png' },
  { id: 'p25', title: 'OnePlus 12 5G 256GB Smartphone', seller: 'Amazon India', price: 749, condition: 'New', match: 95, image: '/images/product-catalog.png' },
  { id: 'p26', title: 'HP Pavilion 14 Intel Core i5 Laptop', seller: 'Vijay Sales', price: 699, condition: 'New', match: 90, image: '/images/product-catalog.png' },
]

const navItems = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'Match products', icon: Network, active: true },
  { label: 'Search index', icon: Search },
  { label: 'Price trends', icon: BarChart3 },
]

const USD_TO_INR = 83.5

function formatPrice(price: number) {
  return (price * USD_TO_INR).toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })
}

export default function Page() {
  const [query, setQuery] = useState('Sony WH-1000XM5')
  const [sortBy, setSortBy] = useState<'match' | 'price'>('match')
  const [showFilters, setShowFilters] = useState(false)
  const [selectedId, setSelectedId] = useState('p1')
  const [activeNav, setActiveNav] = useState('Match products')
  const [chatOpen, setChatOpen] = useState(false)
  const [chatInput, setChatInput] = useState('')
  const [chatLoading, setChatLoading] = useState(false)
  const [chatMessages, setChatMessages] = useState([{ role: 'assistant', text: 'Hi! I can help you find a product, compare Indian prices, or explain the DSA behind a match.' }])
  const [savedProducts, setSavedProducts] = useState<string[]>([])
  const [cartProducts, setCartProducts] = useState<string[]>([])
  const [showCart, setShowCart] = useState(false)
  const [alertEnabled, setAlertEnabled] = useState(false)
  const [chatFeedback, setChatFeedback] = useState<Record<number, 'up' | 'down'>>({})
  const [showChatSuggestions, setShowChatSuggestions] = useState(true)
  const [showNotifications, setShowNotifications] = useState(false)

  function openSellerPage(seller: string, productTitle = '') {
    const search = encodeURIComponent(productTitle)
    const productLinks: Record<string, string> = {
      Amazon: `https://www.amazon.in/s?k=${search}`, 'Amazon India': `https://www.amazon.in/s?k=${search}`,
      Flipkart: `https://www.flipkart.com/search?q=${search}`, Croma: `https://www.croma.com/search?q=${search}`,
      'Reliance Digital': `https://www.reliancedigital.in/search?q=${search}`, 'Vijay Sales': `https://www.vijaysales.com/search?q=${search}`,
      Cashify: `https://www.cashify.in/search?query=${search}`, Myntra: `https://www.myntra.com/${search.replace(/%20/g, '-')}`,
      'Tata Cliq': `https://www.tatacliq.com/search/?searchCategory=all&text=${search}`, OLX: `https://www.olx.in/items/q-${search.replace(/%20/g, '-')}`,
      eBay: `https://www.ebay.in/sch/i.html?_nkw=${search}`,
    }
    const destination = productLinks[seller] ?? `https://www.google.com/search?q=${encodeURIComponent(`${seller} ${productTitle}`)}`
    window.open(destination, '_blank', 'noopener,noreferrer')
  }

  function toggleSaved(id: string) {
    setSavedProducts((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])
  }

  function addToCart(id: string) {
    setCartProducts((current) => current.includes(id) ? current : [...current, id])
    setShowCart(true)
  }

  function buyListing(item: Listing) {
    openSellerPage(item.seller, item.title)
  }

  async function askAssistant(prompt?: string) {
    const message = (prompt ?? chatInput).trim()
    if (!message || chatLoading) return
    setChatInput('')
    setChatMessages((current) => [...current, { role: 'user', text: message }])
    setChatLoading(true)
    try {
      const response = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, context: listings.map((item) => `${item.title} | seller: ${item.seller} | price: ${formatPrice(item.price)} | condition: ${item.condition}`).join('; ') }) })
      const data = await response.json()
      setChatMessages((current) => [...current, { role: 'assistant', text: data.text ?? data.error ?? 'Try asking about fans, ACs, phones, or laptops.' }])
    } catch {
      setChatMessages((current) => [...current, { role: 'assistant', text: 'I could not connect right now. Try a product category from the browse chips.' }])
    } finally {
      setChatLoading(false)
    }
  }

  function askSuggestedPrompt(prompt: string) {
    setChatOpen(true)
    setShowChatSuggestions(false)
    setChatInput('')
    window.setTimeout(() => askAssistant(prompt), 0)
  }

  function rateChatMessage(index: number, rating: 'up' | 'down') {
    setChatFeedback((current) => ({ ...current, [index]: rating }))
  }

  const searchOptions = ['Fans', 'AC', 'Phones', 'Mobiles', 'Laptops', 'Headphones', 'Gaming', 'Appliances']
  const chatSuggestions = ['Find the best laptop under ₹60,000', 'Compare AC prices', 'Explain the HashMap method']

  const filteredListings = useMemo(() => {
    const normalizedQuery = query.toLowerCase().trim()
    const aliases: Record<string, string[]> = {
      fans: ['fan', 'cooler'],
      ac: ['air conditioner', 'split ac', 'ac'],
      phones: ['phone', 'mobile', 'galaxy', 'iphone'],
      mobiles: ['phone', 'mobile', 'galaxy', 'iphone'],
      laptops: ['laptop', 'macbook', 'notebook'],
      headphones: ['headphone', 'headset', 'sony wh'],
      gaming: ['playstation', 'xbox', 'gaming'],
      appliances: ['vacuum', 'dyson', 'fan', 'air conditioner'],
    }
    const terms = aliases[normalizedQuery] ?? [normalizedQuery]
    const result = listings.filter((item) => terms.some((term) => item.title.toLowerCase().includes(term)))
    return [...result].sort((a, b) => sortBy === 'price' ? a.price - b.price : b.match - a.match)
  }, [query, sortBy])

  const selected = listings.find((item) => item.id === selectedId) ?? listings[0]
  const savings = Math.max(0, selected.price - Math.min(...listings.map((item) => item.price)))

  return (
    <main className="min-h-screen bg-[#f6f8f7] text-[#17343a]">
      <div className="flex min-h-screen">
        <aside className="hidden w-[220px] shrink-0 border-r border-[#dce7e3] bg-[#fbfcfb] px-4 py-5 lg:flex lg:flex-col">
          <div className="flex items-center gap-2 px-2">
            <div className="grid size-9 place-items-center rounded-xl bg-[#0b5860] text-white shadow-sm"><Sparkles size={18} /></div>
            <div><p className="text-[15px] font-bold tracking-[-0.02em]">MatchLab</p><p className="text-[10px] font-medium uppercase tracking-[0.18em] text-[#72908d]">Product intelligence</p></div>
          </div>
          <div className="mt-10 flex flex-col gap-1">
            <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[#90a6a2]">Workspace</p>
            {navItems.map(({ label, icon: Icon, active }) => (
              <button key={label} onClick={() => setActiveNav(label)} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] font-semibold transition ${activeNav === label ? 'bg-[#e7f3ef] text-[#0b5860]' : 'text-[#68807d] hover:bg-[#f0f5f3]'}`}>
                <Icon size={17} strokeWidth={activeNav === label ? 2.4 : 1.8} />{label}
              </button>
            ))}
          </div>
          <div className="mt-8 flex flex-col gap-1">
            <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[#90a6a2]">Learn DSA</p>
            <button className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] font-semibold text-[#68807d] hover:bg-[#f0f5f3]"><BookOpen size={17} />Concepts library</button>
            <button className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] font-semibold text-[#68807d] hover:bg-[#f0f5f3]"><Hash size={17} />Algorithm notes</button>
          </div>
          <div className="mt-auto rounded-xl border border-[#dce7e3] bg-[#f0f7f4] p-3.5">
            <div className="mb-2 flex items-center justify-between"><span className="text-[11px] font-bold text-[#3e6967]">INDEX HEALTH</span><span className="size-2 rounded-full bg-[#2e9d76]" /></div>
            <p className="text-[12px] leading-5 text-[#61817c]">12,480 products indexed<br />Last updated 4 min ago</p>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex h-[72px] items-center justify-between border-b border-[#dce7e3] bg-[#fbfcfb] px-5 md:px-8">
            <div className="flex items-center gap-3"><button className="grid size-9 place-items-center rounded-lg border border-[#dce7e3] text-[#68807d] lg:hidden"><Menu size={17} /></button><div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#91a5a2]">Workspace / {activeNav}</p><h1 className="mt-1 text-[19px] font-bold tracking-[-0.03em]">Entity resolution studio</h1></div></div>
            <div className="flex items-center gap-2"><button onClick={() => setShowCart((value) => !value)} aria-label="Open shopping cart" className="relative grid size-9 place-items-center rounded-lg border border-[#dce7e3] bg-white text-[#68807d] hover:bg-[#f0f5f3]"><ShoppingBag size={16} />{cartProducts.length > 0 && <span className="absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-[#0b5860] text-[9px] font-bold text-white">{cartProducts.length}</span>}</button><button onClick={() => setShowNotifications((value) => !value)} aria-label="Open price notifications" className="relative grid size-9 place-items-center rounded-lg border border-[#dce7e3] bg-white text-[#68807d] hover:bg-[#f0f5f3]"><Bell size={16} />{alertEnabled && <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[#e47b5b]" />}</button><button className="hidden items-center gap-2 rounded-lg border border-[#dce7e3] bg-white px-3 py-2 text-[12px] font-semibold text-[#68807d] sm:flex"><Settings2 size={15} /> Settings</button><div className="grid size-9 place-items-center rounded-full bg-[#f0c5a7] text-[12px] font-bold text-[#7c4935]">AR</div></div>
          </header>
          {showCart && <div className="absolute right-5 top-[62px] z-10 w-[min(360px,calc(100vw-32px))] rounded-2xl border border-[#cfe5dc] bg-white p-4 shadow-[0_18px_50px_rgba(24,63,57,0.16)] md:right-8"><div className="flex items-center justify-between"><div><p className="text-[13px] font-bold text-[#29484a]">Your cart</p><p className="mt-1 text-[11px] text-[#8aa19d]">{cartProducts.length} saved item{cartProducts.length === 1 ? '' : 's'} ready to buy.</p></div><ShoppingBag size={17} className="text-[#0b5860]" /></div>{cartProducts.length === 0 ? <p className="mt-4 rounded-xl bg-[#f7faf9] p-3 text-[11px] text-[#78928d]">Add a product from the selected entity card to start shopping.</p> : <div className="mt-3 flex flex-col gap-2">{cartProducts.map((id) => { const item = listings.find((listing) => listing.id === id); return item ? <div key={id} className="flex items-center gap-2 rounded-xl bg-[#f7faf9] p-2"><span className="grid size-8 place-items-center overflow-hidden rounded-lg bg-[#f6f0eb]"><img src={item.image} alt={`${item.title} product`} className="size-full object-cover" /></span><div className="min-w-0 flex-1"><p className="truncate text-[11px] font-bold text-[#29484a]">{item.title}</p><p className="text-[10px] text-[#78928d]">{formatPrice(item.price)} at {item.seller}</p></div><button onClick={() => buyListing(item)} className="rounded-lg bg-[#0b5860] px-2 py-1.5 text-[10px] font-bold text-white">Buy</button></div> : null })}</div>}</div>}
          {showNotifications && <div className="absolute right-5 top-[62px] z-10 w-[min(340px,calc(100vw-32px))] rounded-2xl border border-[#cfe5dc] bg-white p-4 shadow-[0_18px_50px_rgba(24,63,57,0.16)] md:right-8"><div className="flex items-center justify-between"><div><p className="text-[13px] font-bold text-[#29484a]">Price notifications</p><p className="mt-1 text-[11px] text-[#8aa19d]">Stay ahead of verified drops.</p></div><Bell size={17} className="text-[#0b5860]" /></div><div className="mt-3 rounded-xl bg-[#f0f8f4] p-3"><p className="text-[11px] font-bold text-[#26725f]">Sony XM5 dropped 8%</p><p className="mt-1 text-[10px] text-[#6e8e88]">Best offer now {formatPrice(Math.min(...listings.map((item) => item.price)))} at eBay.</p></div><button onClick={() => setAlertEnabled((value) => !value)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#cfe5dc] py-2 text-[11px] font-bold text-[#26725f] hover:bg-[#f0f8f4]">{alertEnabled ? 'Price alert enabled' : 'Enable price alerts'}</button></div>}

          <div className="mx-auto max-w-[1250px] px-5 py-7 md:px-8 lg:px-10">
            <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="mb-2 inline-flex items-center gap-2 rounded-full bg-[#e7f3ef] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-[#2a7565]"><Network size={13} /> DSA-powered workflow</div><h2 className="text-[30px] font-bold tracking-[-0.045em] md:text-[36px]">Find the best match.</h2><p className="mt-1 text-[14px] text-[#71908b]">Resolve duplicate listings, compare sellers, and surface the best price.</p></div><div className="flex items-center gap-2 text-[11px] font-semibold text-[#75908c]"><span className="size-2 rounded-full bg-[#2e9d76]" />Live index <span className="text-[#adc0bd]">•</span> 12.4k entities</div></div>

            <div className="rounded-2xl border border-[#dce7e3] bg-white p-3 shadow-[0_8px_30px_rgba(24,63,57,0.04)] md:p-4"><div className="flex flex-col gap-3 md:flex-row"><div className="relative flex-1"><Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#91a9a5]" size={18} /><input value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search products" className="h-12 w-full rounded-xl border border-[#dce7e3] bg-[#fbfcfb] pl-11 pr-4 text-[14px] font-medium outline-none transition placeholder:text-[#a7b8b5] focus:border-[#75afa3] focus:ring-4 focus:ring-[#e7f3ef]" placeholder="Search by product name, SKU, or identifier..." /><kbd className="absolute right-3 top-3 hidden rounded border border-[#dce7e3] bg-white px-1.5 py-0.5 text-[10px] text-[#90a6a2] sm:block">⌘ K</kbd></div><button onClick={() => setShowFilters((value) => !value)} className={`flex h-12 items-center justify-center gap-2 rounded-xl border px-4 text-[13px] font-bold transition ${showFilters ? 'border-[#9bc9bd] bg-[#e7f3ef] text-[#0b5860]' : 'border-[#dce7e3] bg-white text-[#5c7874] hover:bg-[#f7faf9]'}`}><SlidersHorizontal size={16} /> Filters <span className="grid size-5 place-items-center rounded-full bg-[#e7f3ef] text-[10px] text-[#307465]">2</span></button><button className="flex h-12 items-center justify-center gap-2 rounded-xl bg-[#0b5860] px-5 text-[13px] font-bold text-white shadow-sm transition hover:bg-[#084950]"><Sparkles size={16} /> Resolve entities</button></div><div className="mt-3 flex flex-wrap items-center gap-2"><span className="mr-1 text-[11px] font-bold uppercase tracking-[0.12em] text-[#91a5a2]">Browse:</span>{searchOptions.map((option) => <button key={option} onClick={() => setQuery(option)} className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${query === option ? 'border-[#9bc9bd] bg-[#e7f3ef] text-[#0b5860]' : 'border-[#dce7e3] bg-white text-[#68807d] hover:border-[#9bc9bd] hover:text-[#0b5860]'}`}>{option}</button>)}{query && <button onClick={() => setQuery('')} className="ml-1 text-[11px] font-bold text-[#8aa19d] hover:text-[#0b5860]">Clear search</button>}</div>{showFilters && <div className="mt-3 flex flex-wrap gap-2 border-t border-[#edf2f0] pt-3"><span className="rounded-full bg-[#eef6f3] px-3 py-1.5 text-[11px] font-semibold text-[#3b7569]">Category: Electronics <X size={12} className="ml-1 inline" /></span><span className="rounded-full bg-[#eef6f3] px-3 py-1.5 text-[11px] font-semibold text-[#3b7569]">Region: India <X size={12} className="ml-1 inline" /></span><button className="px-2 text-[11px] font-bold text-[#73908b]">Clear all</button></div>}</div>

            <div className="mt-7 grid gap-5 xl:grid-cols-[minmax(0,1fr)_330px]">
              <div className="min-w-0"><div className="mb-3 flex items-center justify-between"><div><h3 className="text-[15px] font-bold">Match results</h3><p className="mt-0.5 text-[12px] text-[#839b97]">{filteredListings.length} listings grouped into 1 product entity</p></div><button onClick={() => setSortBy(sortBy === 'match' ? 'price' : 'match')} className="flex items-center gap-2 rounded-lg border border-[#dce7e3] bg-white px-3 py-2 text-[11px] font-bold text-[#68807d]"><ArrowUpDown size={14} /> Sort: {sortBy === 'match' ? 'Match score' : 'Price'} <ChevronDown size={14} /></button></div>
                <div className="overflow-hidden rounded-2xl border border-[#dce7e3] bg-white shadow-[0_8px_30px_rgba(24,63,57,0.04)]"><div className="grid grid-cols-[minmax(0,1fr)_100px_110px_86px] border-b border-[#edf2f0] bg-[#fbfcfb] px-4 py-3 text-[10px] font-bold uppercase tracking-[0.12em] text-[#91a5a2] md:grid-cols-[minmax(0,1fr)_110px_125px_100px]"><span>Listing / source</span><span>Match score</span><span>Condition</span><span className="text-right">Price</span></div>{filteredListings.map((item, index) => <div key={item.id} role="button" tabIndex={0} onClick={() => setSelectedId(item.id)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setSelectedId(item.id) } }} className={`grid w-full grid-cols-[minmax(0,1fr)_100px_110px_86px] items-center border-b border-[#edf2f0] px-4 py-4 text-left transition last:border-0 hover:bg-[#f8fbfa] md:grid-cols-[minmax(0,1fr)_110px_125px_100px] ${selectedId === item.id ? 'bg-[#f1f8f5]' : ''}`}><div className="flex min-w-0 items-center gap-3"><div className="size-10 shrink-0 overflow-hidden rounded-xl bg-[#f6f0eb]"><img src={item.image} alt={`${item.title} product`} className="size-full object-cover" /></div><div className="min-w-0"><div className="flex items-center gap-2"><p className="truncate text-[13px] font-bold text-[#29484a]">{item.title}</p>{item.isCanonical && <span className="hidden shrink-0 rounded-full bg-[#d9f0e7] px-1.5 py-0.5 text-[9px] font-bold text-[#26725f] md:inline">CANONICAL</span>}</div><p className="mt-1 text-[11px] font-semibold text-[#91a5a2]">{item.seller} <span className="mx-1">•</span> ID: {item.id.toUpperCase()}0{index + 1}</p></div><button type="button" aria-label={`Add ${item.title} to cart`} onClick={(event) => { event.stopPropagation(); addToCart(item.id) }} className={`hidden rounded-lg p-2 transition md:block ${cartProducts.includes(item.id) ? 'text-[#26725f]' : 'text-[#90a6a2] hover:bg-[#e7f3ef] hover:text-[#0b5860]'}`}><ShoppingBag size={15} /></button><span role="button" tabIndex={0} aria-label={`Save ${item.title}`} onClick={(event) => { event.stopPropagation(); toggleSaved(item.id) }} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopPropagation(); toggleSaved(item.id) } }} className={`ml-auto hidden rounded-lg p-2 transition md:block ${savedProducts.includes(item.id) ? 'bg-[#e7f3ef] text-[#0b5860]' : 'text-[#a2b5b1] hover:bg-[#f0f5f3]'}`}><Bookmark size={15} fill={savedProducts.includes(item.id) ? 'currentColor' : 'none'} /></span></div><div><span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] font-bold ${item.match > 94 ? 'bg-[#dff2e9] text-[#26725f]' : item.match > 88 ? 'bg-[#edf5e9] text-[#5e7b46]' : 'bg-[#f5f1df] text-[#927e3c]'}`}><Check size={12} /> {item.match}%</span></div><div className="text-[12px] font-semibold text-[#69817e]"><span className={`mr-1.5 inline-block size-1.5 rounded-full ${item.condition === 'New' ? 'bg-[#55ae8a]' : 'bg-[#e4aa62]'}`} />{item.condition}</div><div className="text-right text-[15px] font-bold text-[#29484a]">{formatPrice(item.price)}</div></div>)}</div></div>

              <aside className="flex flex-col gap-5"><div className="rounded-2xl border border-[#cfe5dc] bg-[#eef8f3] p-5"><div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.11em] text-[#3d7568]"><Tag size={15} /> Best price found</div><span className="rounded-full bg-white/70 px-2 py-1 text-[10px] font-bold text-[#3d7568]">-16%</span></div><div className="flex items-end gap-2"><span className="text-[32px] font-bold tracking-[-0.05em] text-[#174f54]">{formatPrice(Math.min(...listings.map((item) => item.price)))}</span><span className="mb-1 text-[12px] font-semibold text-[#729b90]">at eBay</span></div><p className="mt-2 text-[12px] leading-5 text-[#668d83]">Save {formatPrice(savings)} compared to the selected canonical listing.</p><div className="mt-4 grid grid-cols-2 gap-2"><button onClick={() => openSellerPage('eBay')} className="flex items-center justify-center gap-2 rounded-xl bg-[#0b5860] py-2.5 text-[12px] font-bold text-white hover:bg-[#084950]">Buy on eBay <ExternalLink size={15} /></button><button onClick={() => setAlertEnabled((value) => !value)} className={`flex items-center justify-center gap-2 rounded-xl border py-2.5 text-[12px] font-bold ${alertEnabled ? 'border-[#9bc9bd] bg-[#e7f3ef] text-[#0b5860]' : 'border-[#cfe5dc] text-[#4b706a] hover:bg-[#f7faf9]'}`}><Bell size={14} /> {alertEnabled ? 'Alert on' : 'Alert me'}</button></div></div>
                <div className="rounded-2xl border border-[#dce7e3] bg-white p-5 shadow-[0_8px_30px_rgba(24,63,57,0.04)]"><div className="mb-4 flex items-center justify-between"><div><h3 className="text-[14px] font-bold">Selected entity</h3><p className="mt-1 text-[11px] text-[#8aa19d]">Canonical product record</p></div><Database size={18} className="text-[#76a69c]" /></div><div className="flex items-center gap-3 rounded-xl bg-[#f7faf9] p-3"><div className="size-10 overflow-hidden rounded-lg bg-[#f6f0eb]"><img src={selected.image} alt={`${selected.title} product`} className="size-full object-cover" /></div><div className="min-w-0"><p className="truncate text-[12px] font-bold">{selected.title}</p><p className="mt-1 text-[10px] font-semibold text-[#8aa19d]">Entity ID: ENT-004291</p></div></div><div className="mt-4 flex flex-col gap-2.5 text-[11px]"><div className="flex justify-between"><span className="text-[#8aa19d]">Attributes matched</span><span className="font-bold text-[#4b706a]">8 / 8</span></div><div className="h-1.5 overflow-hidden rounded-full bg-[#e5efeb]"><div className="h-full w-full rounded-full bg-[#55ae8a]" /></div><div className="flex justify-between pt-1"><span className="text-[#8aa19d]">Listings grouped</span><span className="font-bold text-[#4b706a]">{filteredListings.length}</span></div></div><div className="mt-4 grid grid-cols-2 gap-2"><button onClick={() => addToCart(selected.id)} aria-label={cartProducts.includes(selected.id) ? 'Product already in cart' : 'Add product to cart'} className={`flex items-center justify-center gap-1.5 rounded-xl border py-2.5 text-[11px] font-bold transition ${cartProducts.includes(selected.id) ? 'border-[#9bc9bd] bg-[#e7f3ef] text-[#26725f]' : 'border-[#9bc9bd] text-[#0b5860] hover:bg-[#e7f3ef]'}`}>{cartProducts.includes(selected.id) ? <Check size={14} /> : <ShoppingBag size={14} />} {cartProducts.includes(selected.id) ? 'Added to cart' : 'Add to cart'}</button><button onClick={() => buyListing(selected)} className="flex items-center justify-center gap-1.5 rounded-xl bg-[#0b5860] py-2.5 text-[11px] font-bold text-white hover:bg-[#084950]"><ExternalLink size={14} /> Buy now</button></div></div></aside>
              </div>

            <div className="mt-7 grid gap-5 lg:grid-cols-[1.35fr_1fr_1fr]"><div className="rounded-2xl border border-[#dce7e3] bg-[#173f45] p-5 text-white shadow-[0_8px_30px_rgba(24,63,57,0.08)]"><div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#9dd5c5]">Market pulse</p><h3 className="mt-2 text-[20px] font-bold tracking-[-0.03em]">Smart picks this week</h3></div><TrendingDown size={19} className="text-[#9dd5c5]" /></div><div className="mt-5 flex items-end gap-2"><span className="text-[30px] font-bold tracking-[-0.05em]">12.8%</span><span className="mb-1 text-[11px] text-[#b8d8d0]">average price drop</span></div><div className="mt-4 flex h-10 items-end gap-1.5">{[35, 48, 42, 64, 56, 78, 92, 76, 100, 88].map((height, index) => <div key={index} className="flex-1 rounded-t bg-[#72c3ab]" style={{ height: `${height}%`, opacity: 0.45 + index * 0.05 }} />)}</div><div className="mt-4 flex items-center gap-3"><div className="flex-1"><div className="flex h-8 items-end gap-1">{[62, 48, 56, 42, 45, 31, 36, 22, 28, 18].map((height, index) => <div key={`trend-${index}`} className="flex-1 rounded-t bg-[#d7f1e8]" style={{ height: `${height}%`, opacity: 0.5 + index * 0.04 }} />)}</div><div className="mt-1 flex justify-between text-[9px] text-[#94c8bb]"><span>10 Jun</span><span>16 Jun</span></div></div><span className="rounded-full bg-[#2e9d76]/20 px-2 py-1 text-[10px] font-bold text-[#bce8da]">↓ 12.8%</span></div><p className="mt-3 text-[11px] text-[#b8d8d0]">Electronics are trending lower across 18 sellers.</p></div><div className="rounded-2xl border border-[#dce7e3] bg-white p-5"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#91a5a2]">Saved watchlist</p><h3 className="mt-2 text-[20px] font-bold tracking-[-0.03em]">{savedProducts.length} products</h3></div><Bookmark size={19} className="text-[#76a69c]" /></div><p className="mt-3 text-[12px] leading-5 text-[#78928d]">Keep products here while you compare sellers and prices.</p><button onClick={() => setQuery(savedProducts.length ? listings.find((item) => item.id === savedProducts[0])?.title ?? query : 'Laptops')} className="mt-5 w-full rounded-xl border border-[#cfe5dc] bg-[#f0f8f4] py-2.5 text-[11px] font-bold text-[#26725f] hover:bg-[#e2f2eb]">{savedProducts.length ? 'Review saved products' : 'Explore laptops'}</button></div><div className="rounded-2xl border border-[#dce7e3] bg-white p-5"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#91a5a2]">Price watch</p><h3 className="mt-2 text-[20px] font-bold tracking-[-0.03em]">{alertEnabled ? 'Alert active' : 'Never miss a drop'}</h3></div><Bell size={19} className={alertEnabled ? 'text-[#2e9d76]' : 'text-[#76a69c'} /></div><p className="mt-3 text-[12px] leading-5 text-[#78928d]">Get a signal when the selected product falls below its current best price.</p><button onClick={() => setAlertEnabled((enabled) => !enabled)} className={`mt-5 w-full rounded-xl py-2.5 text-[11px] font-bold transition ${alertEnabled ? 'bg-[#dff2e9] text-[#26725f]' : 'bg-[#0b5860] text-white hover:bg-[#084950]'}`}>{alertEnabled ? 'Price alert enabled' : 'Set price alert'}</button></div></div>

            <div className="mt-7 grid gap-5 md:grid-cols-3"><div className="rounded-2xl border border-[#dce7e3] bg-white p-4"><div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em] text-[#76918d]"><Hash size={15} /> HashMap lookup</div><p className="text-[13px] font-semibold text-[#416460]">O(1) average access</p><p className="mt-1 text-[11px] leading-5 text-[#8aa19d]">Normalized identifier maps directly to the canonical entity record.</p></div><div className="rounded-2xl border border-[#dce7e3] bg-white p-4"><div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em] text-[#76918d]"><ListFilter size={15} /> String matching</div><p className="text-[13px] font-semibold text-[#416460]">Levenshtein + tokens</p><p className="mt-1 text-[11px] leading-5 text-[#8aa19d]">Titles are normalized, tokenized, and scored against the canonical name.</p></div><div className="rounded-2xl border border-[#dce7e3] bg-white p-4"><div className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em] text-[#76918d]"><TrendingDown size={15} /> Sort by price</div><p className="text-[13px] font-semibold text-[#416460]">O(n log n) ordering</p><p className="mt-1 text-[11px] leading-5 text-[#8aa19d]">A stable sort surfaces the lowest verified offer across sellers.</p></div></div>
          </div>
        </section>
      </div>

      <div className="fixed bottom-5 right-5 z-20 flex flex-col items-end gap-3">
        {chatOpen && <div className="w-[min(360px,calc(100vw-32px))] overflow-hidden rounded-2xl border border-[#cfe5dc] bg-white shadow-[0_20px_60px_rgba(24,63,57,0.18)]">
          <div className="flex items-center justify-between bg-[#0b5860] px-4 py-3 text-white"><div><p className="text-[13px] font-bold">MatchLab Guide</p><p className="text-[10px] text-[#bfe1d8]">AI product scout</p></div><button aria-label="Close assistant" onClick={() => setChatOpen(false)} className="rounded-lg p-1.5 hover:bg-white/10"><X size={16} /></button></div>
          <div className="flex max-h-64 flex-col gap-3 overflow-y-auto bg-[#f7faf9] p-3">{chatMessages.map((item, index) => <div key={`${item.role}-${index}`} className={`group relative max-w-[88%] rounded-xl px-3 py-2 text-[12px] leading-5 ${item.role === 'user' ? 'self-end bg-[#dff2e9] text-[#245c52]' : 'self-start border border-[#dce7e3] bg-white text-[#456662]'}`}><span>{item.text}</span>{item.role === 'assistant' && index > 0 && <div className="mt-2 flex gap-1 opacity-0 transition group-hover:opacity-100"><button onClick={() => rateChatMessage(index, 'up')} aria-label="Helpful response" className={`rounded px-1.5 py-0.5 text-[10px] ${chatFeedback[index] === 'up' ? 'bg-[#dff2e9] text-[#26725f]' : 'text-[#90a6a2] hover:bg-[#f0f5f3]'}`}>Helpful</button><button onClick={() => rateChatMessage(index, 'down')} aria-label="Not helpful response" className={`rounded px-1.5 py-0.5 text-[10px] ${chatFeedback[index] === 'down' ? 'bg-[#f8e8e3] text-[#a35f4c]' : 'text-[#90a6a2] hover:bg-[#f0f5f3]'}`}>Not quite</button></div>}</div>)}{chatLoading && <div className="self-start rounded-xl border border-[#dce7e3] bg-white px-3 py-2 text-[12px] text-[#78928d]">Thinking...</div>}</div>
          {showChatSuggestions && !chatLoading && <div className="flex flex-wrap gap-1.5 border-t border-[#edf2f0] bg-[#fbfcfb] px-3 py-2">{chatSuggestions.map((prompt) => <button key={prompt} onClick={() => askSuggestedPrompt(prompt)} className="rounded-full border border-[#cfe5dc] bg-white px-2.5 py-1.5 text-left text-[10px] font-semibold text-[#4b706a] hover:border-[#75afa3] hover:text-[#0b5860]">{prompt}</button>)}</div>}
          <div className="flex gap-2 border-t border-[#edf2f0] bg-white p-3"><input value={chatInput} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing && event.keyCode !== 229) askAssistant() }} aria-label="Ask MatchLab Guide" placeholder="Ask about a product..." className="min-w-0 flex-1 rounded-lg border border-[#dce7e3] px-3 py-2 text-[12px] outline-none focus:border-[#75afa3]" /><button onClick={() => askAssistant()} aria-label="Send message" className="grid size-9 shrink-0 place-items-center rounded-lg bg-[#0b5860] text-white hover:bg-[#084950]"><Send size={15} /></button></div>
        </div>}
        <button onClick={() => setChatOpen((open) => !open)} aria-label="Open AI shopping assistant" className="flex items-center gap-2 rounded-full bg-[#0b5860] px-4 py-3 text-[12px] font-bold text-white shadow-[0_10px_30px_rgba(11,88,96,0.25)] transition hover:-translate-y-0.5 hover:bg-[#084950]"><MessageCircle size={17} /> AI shopping guide</button>
      </div>
    </main>
  )
}
