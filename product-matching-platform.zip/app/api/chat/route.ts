import { gateway } from '@ai-sdk/gateway'
import { generateText } from 'ai'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const { message, context } = (await request.json()) as { message?: string; context?: string }
    if (!message?.trim()) return NextResponse.json({ error: 'Message is required' }, { status: 400 })

    const result = await generateText({
      model: gateway('openai/o4-mini'),
      system: `You are MatchLab Guide, a concise shopping and DSA assistant inside an Indian product comparison app. Help users discover products, compare value, explain entity resolution, and suggest search terms. Use Indian Rupees when discussing prices. Current catalog context: ${context ?? 'Product comparison catalog'}. Keep replies under 90 words and actionable.`,
      prompt: message.trim(),
    })

    return NextResponse.json({ text: result.text })
  } catch (error) {
    console.error('[v0] AI chat error:', error)
    return NextResponse.json({ error: 'The assistant is temporarily unavailable.' }, { status: 500 })
  }
}
